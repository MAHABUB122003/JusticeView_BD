from src.database.mongodb_connection import MongoDB
from src.engine.rule_engine import RuleEngine
from src.security.auth import Auth
from src.utils.logger import Logger
from datetime import datetime
from bson.objectid import ObjectId
import uuid
import hashlib

class AdminAPI:
    def __init__(self):
        self.db = MongoDB()
        self.rule_engine = RuleEngine()
        self.auth = Auth()
        self.logger = Logger()

    def get_stats(self):
        total_requests = self.db.requests.count_documents({})
        total_attacks = self.db.attacks.count_documents({})
        attack_types_raw = list(self.db.attacks.aggregate([
            {'$group': {'_id': '$attack_type', 'count': {'$sum': 1}}}
        ]))
        attack_types = [item['_id'] for item in attack_types_raw]
        attack_counts = [item['count'] for item in attack_types_raw]
        top_attackers = list(self.db.attacks.aggregate([
            {'$group': {'_id': '$ip', 'count': {'$sum': 1}}},
            {'$sort': {'count': -1}},
            {'$limit': 10}
        ]))
        recent_logs = list(self.db.attacks.find().sort('timestamp', -1).limit(10))
        for log in recent_logs:
            if '_id' in log:
                log['_id'] = str(log['_id'])
            if 'timestamp' in log and log['timestamp']:
                log['timestamp'] = log['timestamp'].strftime('%Y-%m-%d %H:%M:%S')
        return {
            'total_requests': total_requests,
            'total_attacks_blocked': total_attacks,
            'active_clients': self.db.clients.count_documents({'status': 'active'}),
            'blacklisted_ips': self.db.blacklist.count_documents({}),
            'attack_types': attack_types,
            'attack_counts': attack_counts,
            'top_attackers': [{'ip': item['_id'], 'count': item['count']} for item in top_attackers],
            'recent_logs': recent_logs
        }

    def get_logs(self, args):
        page = int(args.get('page', 1))
        per_page = 50
        search = args.get('search', '')
        ip_filter = args.get('ip', '')
        attack_type = args.get('attack_type', '')
        status = args.get('status', '')
        date_from = args.get('date_from', '')
        date_to = args.get('date_to', '')
        query = {}
        if search:
            query['$or'] = [
                {'ip': {'$regex': search, '$options': 'i'}},
                {'url': {'$regex': search, '$options': 'i'}},
                {'attack_type': {'$regex': search, '$options': 'i'}}
            ]
        if ip_filter:
            query['ip'] = ip_filter
        if attack_type:
            query['attack_type'] = attack_type
        if status:
            query['status'] = status
        if date_from or date_to:
            query['timestamp'] = {}
            if date_from:
                try:
                    query['timestamp']['$gte'] = datetime.strptime(date_from, '%Y-%m-%d')
                except:
                    pass
            if date_to:
                try:
                    query['timestamp']['$lte'] = datetime.strptime(date_to + ' 23:59:59', '%Y-%m-%d %H:%M:%S')
                except:
                    pass
        total = self.db.attacks.count_documents(query)
        logs = list(self.db.attacks.find(query)
            .sort('timestamp', -1)
            .skip((page - 1) * per_page)
            .limit(per_page))
        result_logs = []
        for i, log in enumerate(logs):
            result_logs.append({
                'id': str(log.get('_id', i)),
                'ip': log.get('ip', ''),
                'url': log.get('url', ''),
                'attack_type': log.get('attack_type', 'Unknown'),
                'status': log.get('status', 'blocked'),
                'timestamp': log['timestamp'].strftime('%Y-%m-%d %H:%M:%S') if log.get('timestamp') else '',
                'confidence': log.get('confidence', 0),
                'method': log.get('method', 'GET'),
                'user_agent': log.get('user_agent', ''),
                'referer': log.get('referer', ''),
                'request_body': log.get('request_body', ''),
                'rule_matched': log.get('rule_matched', '')
            })
        return {
            'total': total,
            'page': page,
            'per_page': per_page,
            'total_pages': (total + per_page - 1) // per_page if total > 0 else 1,
            'logs': result_logs
        }

    def get_rules(self):
        rules = []
        for i, rule in enumerate(self.rule_engine.default_rules):
            rules.append({
                'id': str(i),
                'name': rule.get('name', ''),
                'pattern': rule.get('pattern', ''),
                'action': rule.get('action', 'block'),
                'severity': rule.get('severity', 'medium'),
                'enabled': rule.get('enabled', True),
                'created_at': rule.get('created_at', '').isoformat() if rule.get('created_at') else ''
            })
        return rules

    def create_rule(self, data):
        rule = {
            'name': data.get('name'),
            'pattern': data.get('pattern'),
            'action': data.get('action', 'block'),
            'severity': data.get('severity', 'medium'),
            'enabled': True,
            'created_at': datetime.now()
        }
        self.rule_engine.add_rule(rule)
        return {'status': 'success', 'message': 'Rule created successfully'}

    def update_rule(self, rule_id, data):
        try:
            index = int(rule_id)
            self.rule_engine.update_rule(index, data)
            return {'status': 'success', 'message': 'Rule updated successfully'}
        except (ValueError, IndexError):
            return {'status': 'error', 'message': 'Invalid rule ID'}

    def delete_rule(self, rule_id):
        try:
            index = int(rule_id)
            self.rule_engine.delete_rule(index)
            return {'status': 'success', 'message': 'Rule deleted successfully'}
        except (ValueError, IndexError):
            return {'status': 'error', 'message': 'Invalid rule ID'}

    def get_clients(self):
        clients = []
        for client in self.db.clients.find():
            clients.append({
                'id': str(client['_id']),
                'domain': client.get('domain', ''),
                'origin_server': client.get('origin_server', ''),
                'security_level': client.get('security_level', 'high'),
                'api_key': client.get('api_key', ''),
                'status': client.get('status', 'active'),
                'created_at': client['created_at'].strftime('%Y-%m-%d %H:%M:%S') if client.get('created_at') else '',
                'settings': client.get('settings', {})
            })
        return clients

    def add_client(self, data):
        api_key = hashlib.sha256(f"{data.get('domain')}{datetime.now()}{uuid.uuid4()}".encode()).hexdigest()[:32]
        client = {
            'domain': data.get('domain'),
            'origin_server': data.get('origin_server'),
            'security_level': data.get('security_level', 'high'),
            'api_key': api_key,
            'status': 'active',
            'created_at': datetime.now(),
            'updated_at': datetime.now(),
            'settings': {
                'block_sqli': True,
                'block_xss': True,
                'block_lfi': True,
                'block_cmd_injection': True,
                'confidence_threshold': 0.7
            }
        }
        result = self.db.clients.insert_one(client)
        return {'status': 'success', 'id': str(result.inserted_id), 'api_key': api_key, 'message': 'Client added successfully'}

    def update_client(self, client_id, data):
        try:
            oid = ObjectId(client_id)
            update_data = {k: v for k, v in data.items() if k not in ['id', '_id']}
            update_data['updated_at'] = datetime.now()
            self.db.clients.update_one({'_id': oid}, {'$set': update_data})
            return {'status': 'success', 'message': 'Client updated successfully'}
        except:
            return {'status': 'error', 'message': 'Invalid client ID'}

    def delete_client(self, client_id):
        try:
            oid = ObjectId(client_id)
            self.db.clients.delete_one({'_id': oid})
            return {'status': 'success', 'message': 'Client deleted successfully'}
        except:
            return {'status': 'error', 'message': 'Invalid client ID'}

    def get_blacklist(self):
        blacklist = []
        for entry in self.db.blacklist.find().sort('blocked_at', -1):
            blacklist.append({
                'id': str(entry['_id']),
                'ip': entry.get('ip', ''),
                'reason': entry.get('reason', ''),
                'blocked_at': entry['blocked_at'].strftime('%Y-%m-%d %H:%M:%S') if entry.get('blocked_at') else '',
                'type': entry.get('type', 'permanent'),
                'auto_blocked': entry.get('auto_blocked', False)
            })
        return blacklist

    def add_to_blacklist(self, data):
        ip = data.get('ip')
        existing = self.db.blacklist.find_one({'ip': ip})
        if existing:
            return {'status': 'error', 'message': 'IP already blacklisted'}
        self.db.blacklist.insert_one({
            'ip': ip,
            'reason': data.get('reason', 'Manually blocked'),
            'blocked_at': datetime.now(),
            'type': data.get('type', 'permanent'),
            'auto_blocked': False
        })
        return {'status': 'success', 'message': f'IP {ip} blacklisted successfully'}

    def remove_from_blacklist(self, ip):
        self.db.blacklist.delete_one({'ip': ip})
        return {'status': 'success', 'message': f'IP {ip} removed from blacklist'}

    def get_settings(self):
        settings_doc = self.db.settings.find_one({'_type': 'waf_settings'})
        if not settings_doc:
            return {
                'security_level': 'high',
                'confidence_threshold': 0.7,
                'rate_limit': 100,
                'email_alerts': False,
                'smtp_server': '',
                'smtp_port': 587,
                'smtp_username': '',
                'smtp_password': '',
                'alert_email': '',
                'block_logo': '',
                'block_message': 'This request has been blocked by Web Application Firewall',
                'block_colors': '#667eea,#764ba2'
            }
        settings_doc.pop('_id', None)
        settings_doc.pop('_type', None)
        return settings_doc

    def update_settings(self, data):
        self.db.settings.update_one(
            {'_type': 'waf_settings'},
            {'$set': {**data, '_type': 'waf_settings'}},
            upsert=True
        )
        return {'status': 'success', 'message': 'Settings updated successfully'}

    def change_password(self, data):
        old_password = data.get('old_password')
        new_password = data.get('new_password')
        ip = data.get('ip', 'unknown')
        if self.auth.verify_admin('admin', old_password, ip):
            self.auth.update_password('admin', new_password)
            return {'status': 'success', 'message': 'Password changed successfully'}
        return {'status': 'error', 'message': 'Current password is incorrect'}
