import os
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
from dotenv import load_dotenv

load_dotenv()

class MongoDB:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._client = None
            cls._instance._db = None
        return cls._instance

    def __init__(self):
        if self._client is None:
            self._connect()

    def _connect(self):
        try:
            mongo_uri = os.getenv('MONGO_URI', 'mongodb://localhost:27017/')
            db_name = os.getenv('MONGO_DB', 'waf_firewall')
            self._client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
            self._client.admin.command('ping')
            self._db = self._client[db_name]
            self._ensure_indexes()
        except ConnectionFailure:
            print("Warning: MongoDB connection failed. Using in-memory fallback.")
            self._db = InMemoryDB()

    def _ensure_indexes(self):
        if hasattr(self._db, 'attacks'):
            self._db.attacks.create_index('timestamp')
            self._db.attacks.create_index('ip')
            self._db.attacks.create_index('attack_type')
            self._db.blacklist.create_index('ip', unique=True)
            self._db.clients.create_index('api_key')
            self._db.clients.create_index('domain', unique=True)

    @property
    def attacks(self):
        return self._db['attacks'] if self._db is not None else None

    @property
    def requests(self):
        return self._db['requests'] if self._db is not None else None

    @property
    def blacklist(self):
        return self._db['blacklist'] if self._db is not None else None

    @property
    def clients(self):
        return self._db['clients'] if self._db is not None else None

    @property
    def rules(self):
        return self._db['rules'] if self._db is not None else None

    @property
    def settings(self):
        return self._db['settings'] if self._db is not None else None


class InMemoryDB:
    def __init__(self):
        self.attacks = InMemoryCollection()
        self.requests = InMemoryCollection()
        self.blacklist = InMemoryCollection()
        self.clients = InMemoryCollection()
        self.rules = InMemoryCollection()
        self.settings = InMemoryCollection()


class InMemoryCollection:
    def __init__(self):
        self._data = []
        self._index = 0

    def insert_one(self, doc):
        doc['_id'] = str(self._index)
        self._index += 1
        self._data.append(doc)
        return type('obj', (object,), {'inserted_id': doc['_id']})()

    def find(self, query=None, projection=None):
        if query is None:
            return self._data[:]
        results = []
        for doc in self._data:
            if self._matches(doc, query):
                results.append(doc)
        return InMemoryCursor(results)

    def find_one(self, query):
        for doc in self._data:
            if self._matches(doc, query):
                return doc
        return None

    def count_documents(self, query=None):
        if query is None:
            return len(self._data)
        count = 0
        for doc in self._data:
            if self._matches(doc, query):
                count += 1
        return count

    def update_one(self, query, update, upsert=False):
        for i, doc in enumerate(self._data):
            if self._matches(doc, query):
                if '$set' in update:
                    doc.update(update['$set'])
                else:
                    doc.update(update)
                return type('obj', (object,), {'modified_count': 1})()
        if upsert:
            new_doc = query.copy()
            if '$set' in update:
                new_doc.update(update['$set'])
            self._data.append(new_doc)
        return type('obj', (object,), {'modified_count': 0})()

    def delete_one(self, query):
        for i, doc in enumerate(self._data):
            if self._matches(doc, query):
                self._data.pop(i)
                return type('obj', (object,), {'deleted_count': 1})()
        return type('obj', (object,), {'deleted_count': 0})()

    def aggregate(self, pipeline):
        result = []
        data = self._data[:]
        for stage in pipeline:
            if '$group' in stage:
                groups = {}
                group_key = stage['$group'].get('_id')
                for doc in data:
                    key = doc.get(group_key, 'Unknown') if group_key != 'null' else 'total'
                    if key not in groups:
                        groups[key] = {'_id': key}
                    for field, expr in stage['$group'].items():
                        if field == '_id':
                            continue
                        if '$sum' in str(expr):
                            val = 1
                            groups[key][field] = groups[key].get(field, 0) + val
                result = list(groups.values())
            elif '$sort' in stage:
                field = list(stage['$sort'].keys())[0]
                direction = stage['$sort'][field]
                result.sort(key=lambda x: x.get(field, 0), reverse=(direction == -1))
            elif '$limit' in stage:
                result = result[:stage['$limit']]
            elif '$match' in stage:
                data = [d for d in data if self._matches(d, stage['$match'])]
                result = data
        return result

    def _matches(self, doc, query):
        for key, value in query.items():
            if key == '$or':
                if not any(self._matches(doc, cond) for cond in value):
                    return False
                continue
            if key == '$and':
                if not all(self._matches(doc, cond) for cond in value):
                    return False
                continue
            if isinstance(value, dict):
                if '$regex' in value:
                    import re
                    if not re.search(value['$regex'], str(doc.get(key, '')), re.IGNORECASE if value.get('$options', '').lower() == 'i' else 0):
                        return False
                elif '$gte' in value:
                    if not (doc.get(key) and doc[key] >= value['$gte']):
                        return False
                elif '$lte' in value:
                    if not (doc.get(key) and doc[key] <= value['$lte']):
                        return False
                else:
                    if doc.get(key) != value:
                        return False
            else:
                if doc.get(key) != value:
                    return False
        return True

    def create_index(self, field):
        pass

    def sort(self, key, direction=-1):
        self._data.sort(key=lambda x: x.get(key, ''), reverse=(direction == -1))
        return self


class InMemoryCursor:
    def __init__(self, data):
        self._data = data

    def sort(self, key, direction=-1):
        self._data.sort(key=lambda x: x.get(key, ''), reverse=(direction == -1))
        return self

    def skip(self, n):
        self._data = self._data[n:]
        return self

    def limit(self, n):
        self._data = self._data[:n]
        return self

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)
