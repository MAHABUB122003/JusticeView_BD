from src.database.mongodb_connection import MongoDB
from datetime import datetime

class IPFilter:
    def __init__(self):
        self.db = MongoDB()
        self._whitelist = set()

    def is_blacklisted(self, ip):
        return self.db.blacklist.find_one({'ip': ip}) is not None

    def add_to_blacklist(self, ip):
        existing = self.db.blacklist.find_one({'ip': ip})
        if not existing:
            self.db.blacklist.insert_one({
                'ip': ip,
                'reason': 'Auto-blocked by rate limiter',
                'blocked_at': datetime.now(),
                'type': 'temporary',
                'auto_blocked': True
            })

    def remove_from_blacklist(self, ip):
        self.db.blacklist.delete_one({'ip': ip})

    def auto_block(self, ip, reason='Suspicious activity'):
        self.add_to_blacklist(ip)
        self.db.blacklist.update_one(
            {'ip': ip},
            {'$set': {'reason': reason, 'auto_blocked': True}}
        )

    def add_to_whitelist(self, ip):
        self._whitelist.add(ip)

    def is_whitelisted(self, ip):
        return ip in self._whitelist

    def get_blacklist(self):
        return list(self.db.blacklist.find().sort('blocked_at', -1))
