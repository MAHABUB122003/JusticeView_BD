let currentPage = 'overview';
let refreshInterval = null;

document.addEventListener('DOMContentLoaded', function() {
    loadPage('overview');
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            loadPage(page);
            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            this.classList.add('active');
        });
    });
    document.getElementById('refresh-btn').addEventListener('click', function() {
        loadPage(currentPage);
    });
    refreshInterval = setInterval(() => loadPage(currentPage, true), 30000);
});

function loadPage(page, silent = false) {
    currentPage = page;
    const titles = {
        overview: 'Overview',
        logs: 'Attack Logs',
        blacklist: 'Blacklist Management',
        whitelist: 'Whitelist Management',
        settings: 'Settings'
    };
    document.getElementById('page-title').textContent = titles[page] || 'Overview';

    const pages = {
        overview: loadOverview,
        logs: loadLogs,
        blacklist: loadBlacklist,
        whitelist: loadWhitelist,
        settings: loadSettings
    };

    if (pages[page]) {
        pages[page](silent);
    }
}

async function loadOverview(silent) {
    try {
        const [statsRes, blacklistRes] = await Promise.all([
            fetch('/api/admin/stats'),
            fetch('/api/admin/blacklist')
        ]);
        const stats = await statsRes.json();
        const blacklist = await blacklistRes.json();

        let totalAttacks = 0;
        const attackCounts = {};
        if (stats.attack_types && stats.attack_counts) {
            stats.attack_types.forEach((type, i) => {
                const count = stats.attack_counts[i] || 0;
                totalAttacks += count;
                attackCounts[type] = count;
            });
        }

        document.getElementById('total-attacks').textContent = totalAttacks.toLocaleString();
        document.getElementById('recent-attacks').textContent = (stats.recent_attacks_count || 0).toLocaleString();
        document.getElementById('blacklisted-ips').textContent = (Array.isArray(blacklist) ? blacklist.length : 0);

        renderAttackChart(attackCounts);
    } catch (err) {
        if (!silent) console.error('Failed to load overview:', err);
    }
}

function renderAttackChart(attackCounts) {
    const container = document.getElementById('attack-chart');
    const types = Object.keys(attackCounts);
    if (types.length === 0) {
        container.innerHTML = '<p class="loading-text">No attack data available</p>';
        return;
    }
    const maxCount = Math.max(...Object.values(attackCounts));
    const colors = ['#ef5350', '#ffa726', '#66bb6a', '#42a5f5', '#ab47bc', '#ec407a'];
    let html = '<div style="display:flex; flex-direction:column; gap:12px;">';
    types.forEach((type, i) => {
        const count = attackCounts[type];
        const pct = (count / maxCount * 100).toFixed(0);
        const color = colors[i % colors.length];
        html += `
            <div>
                <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
                    <span style="font-size:13px;color:rgba(255,255,255,0.7);">${type}</span>
                    <span style="font-size:13px;color:#fff;font-weight:600;">${count}</span>
                </div>
                <div style="height:8px;background:rgba(255,255,255,0.05);border-radius:4px;overflow:hidden;">
                    <div style="height:100%;width:${pct}%;background:${color};border-radius:4px;transition:width 0.5s;"></div>
                </div>
            </div>
        `;
    });
    html += '</div>';
    container.innerHTML = html;
}

async function loadLogs(silent) {
    const container = document.getElementById('page-content');
    try {
        const res = await fetch('/api/admin/logs?limit=100');
        const data = await res.json();
        const logs = data.logs || [];
        if (logs.length === 0) {
            container.innerHTML = '<div class="card"><p class="loading-text">No logs found</p></div>';
            return;
        }
        let html = '<div class="card"><table><thead><tr><th>Timestamp</th><th>IP</th><th>Attack Type</th><th>Confidence</th><th>URL</th></tr></thead><tbody>';
        logs.forEach(log => {
            const ts = log.timestamp ? new Date(log.timestamp).toLocaleString() : '-';
            const confidence = (log.confidence * 100).toFixed(0);
            const badgeClass = confidence > 80 ? 'badge-danger' : confidence > 50 ? 'badge-warning' : 'badge-info';
            html += `<tr>
                <td>${ts}</td>
                <td>${log.ip || '-'}</td>
                <td><span class="badge ${badgeClass}">${log.attack_type || 'Unknown'}</span></td>
                <td>${confidence}%</td>
                <td style="max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${log.url || '-'}</td>
            </tr>`;
        });
        html += '</tbody></table></div>';
        container.innerHTML = html;
    } catch (err) {
        container.innerHTML = '<div class="card"><p class="loading-text">Failed to load logs</p></div>';
    }
}

async function loadBlacklist() {
    const container = document.getElementById('page-content');
    try {
        const res = await fetch('/api/admin/blacklist');
        const list = await res.json();
        let html = `
            <div class="card">
                <h3>Add to Blacklist</h3>
                <div class="form-group">
                    <label>IP Address</label>
                    <input type="text" id="block-ip-input" placeholder="e.g. 192.168.1.100">
                </div>
                <div class="form-group">
                    <label>Reason</label>
                    <input type="text" id="block-reason-input" placeholder="e.g. Malicious activity">
                </div>
                <button class="btn btn-danger" onclick="blockIP()">Block IP</button>
            </div>
            <div class="card">
                <h3>Blacklisted IPs (${list.length})</h3>
                <table>
                    <thead><tr><th>IP</th><th>Reason</th><th>Created</th><th>Expires</th><th>Action</th></tr></thead>
                    <tbody>
        `;
        if (list.length === 0) {
            html += '<tr><td colspan="5" style="text-align:center;color:rgba(255,255,255,0.3);">No blacklisted IPs</td></tr>';
        } else {
            list.forEach(item => {
                html += `<tr>
                    <td>${item.ip}</td>
                    <td>${item.reason || '-'}</td>
                    <td>${item.blocked_at ? item.blocked_at : '-'}</td>
                    <td>${item.type === 'temporary' ? 'Temporary' : 'Permanent'}</td>
                    <td><button class="btn-small" style="border-color:#ef5350;color:#ef5350;" onclick="unblockIP('${item.ip}')">Unblock</button></td>
                </tr>`;
            });
        }
        html += '</tbody></table></div>';
        container.innerHTML = html;
    } catch (err) {
        container.innerHTML = '<div class="card"><p class="loading-text">Failed to load blacklist</p></div>';
    }
}

async function loadWhitelist() {
    const container = document.getElementById('page-content');
    let html = `
        <div class="card">
            <h3>Whitelisted IPs</h3>
            <p class="loading-text">Whitelist management available via API</p>
        </div>
    `;
    container.innerHTML = html;
}

function loadSettings() {
    const container = document.getElementById('page-content');
    container.innerHTML = `
        <div class="card">
            <h3>WAF Settings</h3>
            <p class="loading-text">Configuration management coming soon</p>
        </div>
    `;
}

async function blockIP() {
    const ip = document.getElementById('block-ip-input').value.trim();
    const reason = document.getElementById('block-reason-input').value.trim() || 'Manual block';
    if (!ip) { alert('Please enter an IP address'); return; }
    try {
        const res = await fetch('/api/admin/blacklist', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ip, reason})
        });
        if (res.ok) {
            document.getElementById('block-ip-input').value = '';
            document.getElementById('block-reason-input').value = '';
            loadBlacklist();
        } else {
            alert('Failed to block IP');
        }
    } catch (err) {
        alert('Error blocking IP');
    }
}

async function unblockIP(ip) {
    if (!confirm(`Unblock ${ip}?`)) return;
    try {
        const res = await fetch(`/api/admin/blacklist?ip=${encodeURIComponent(ip)}`, {method: 'DELETE'});
        if (res.ok) loadBlacklist();
    } catch (err) {
        alert('Error unblocking IP');
    }
}
